const fs = require('fs')
const path = require('path')
const { execSync } = require('child_process')
const config = require('../config')

const STAGING_DIR = path.join(process.cwd(), 'update-staging')

function copyRecursive(src, dest) {
  fs.mkdirSync(dest, { recursive: true })
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const srcPath  = path.join(src, entry.name)
    const destPath = path.join(dest, entry.name)
    if (entry.isDirectory()) copyRecursive(srcPath, destPath)
    else fs.copyFileSync(srcPath, destPath)
  }
}

async function applyPendingUpdate() {
  if (!fs.existsSync(STAGING_DIR)) return false

  console.log('[update] Aplicando atualização staged...')
  try {
    const versionFile = path.join(STAGING_DIR, 'VERSION')
    const novaVersao = fs.existsSync(versionFile)
      ? fs.readFileSync(versionFile, 'utf8').trim()
      : null

    const srcStaging = path.join(STAGING_DIR, 'src')
    if (fs.existsSync(srcStaging)) {
      copyRecursive(srcStaging, path.join(process.cwd(), 'src'))
    }

    let packageJsonAtualizado = false
    for (const f of ['package.json', 'package-lock.json']) {
      const src = path.join(STAGING_DIR, f)
      if (fs.existsSync(src)) {
        fs.copyFileSync(src, path.join(process.cwd(), f))
        if (f === 'package.json') packageJsonAtualizado = true
      }
    }

    if (packageJsonAtualizado) {
      console.log('[update] Instalando dependências...')
      execSync('npm install --omit=dev', { cwd: process.cwd(), stdio: 'inherit' })
    }

    fs.rmSync(STAGING_DIR, { recursive: true, force: true })

    if (novaVersao) {
      config.set('versao_agente', novaVersao)
      console.log(`[update] Versão aplicada: ${novaVersao}`)
    } else {
      console.log('[update] Atualização aplicada (versão não informada)')
    }
    return true
  } catch (err) {
    console.error(`[update] Falha ao aplicar: ${err.message}`)
    return false
  }
}

module.exports = { applyPendingUpdate }
