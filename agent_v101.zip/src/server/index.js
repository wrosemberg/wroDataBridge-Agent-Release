const express = require('express')
const config = require('../config')
const scheduler = require('../core/scheduler')

const app = express()
app.use(express.json())

app.get('/health', (req, res) => {
  res.json({ status: 'ok', ts: new Date().toISOString() })
})

app.get('/', (req, res) => {
  const gatewayId = config.get('gateway_id')?.valor || '—'
  const versao = config.get('versao_agente')?.valor || '—'
  const repoStatus = scheduler.getStatus()

  res.send(`<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta http-equiv="refresh" content="30">
  <title>DataBridge Agent</title>
  <style>
    body { font-family: monospace; padding: 2rem; background: #0f172a; color: #e2e8f0; }
    h1 { color: #38bdf8; margin: 0 0 .5rem; }
    .badge { display: inline-block; padding: .2rem .6rem; border-radius: .25rem; font-size: .85rem; }
    .online { background: #166534; color: #bbf7d0; }
    .offline { background: #7f1d1d; color: #fecaca; }
    table { border-collapse: collapse; width: 100%; margin-top: 1.5rem; }
    th, td { text-align: left; padding: .5rem .75rem; border-bottom: 1px solid #334155; }
    th { color: #94a3b8; font-weight: normal; }
  </style>
</head>
<body>
  <h1>DataBridge Agent</h1>
  <p>versão: ${versao} &nbsp;|&nbsp; gateway: <code>${gatewayId}</code></p>
  <table>
    <thead><tr><th>Repositório</th><th>Status</th></tr></thead>
    <tbody>
      ${repoStatus.map(r => `<tr><td>${r.nome || r.id}</td><td><span class="badge ${r.status === 'agendado' ? 'online' : 'offline'}">${r.status}</span></td></tr>`).join('')}
    </tbody>
  </table>
</body>
</html>`)
})

function start(port = 8089) {
  app.listen(port, '127.0.0.1', () => {
    console.log(`[server] Interface local: http://localhost:${port}`)
  })
}

module.exports = { start }
