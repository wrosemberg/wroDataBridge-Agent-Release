const db = require('../db/sqlite')

const stmts = {
  get:        db.prepare('SELECT schema_hash, schema_json FROM cursors WHERE repositorio_id = ?'),
  updateHash: db.prepare(`
    INSERT INTO cursors (repositorio_id, schema_hash, atualizado_em)
    VALUES (?, ?, datetime('now'))
    ON CONFLICT(repositorio_id) DO UPDATE SET schema_hash = excluded.schema_hash
  `),
  updateJson: db.prepare(`
    INSERT INTO cursors (repositorio_id, schema_json, atualizado_em)
    VALUES (?, ?, datetime('now'))
    ON CONFLICT(repositorio_id) DO UPDATE SET schema_json = excluded.schema_json
  `)
}

function getCursor(repositorioId) {
  return stmts.get.get(repositorioId) || { schema_hash: null, schema_json: null }
}

function saveSchemaHash(repositorioId, hash) {
  stmts.updateHash.run(repositorioId, hash)
}

function saveSchemaJson(repositorioId, schemaObj) {
  stmts.updateJson.run(repositorioId, JSON.stringify(schemaObj))
}

function getSchemaJson(repositorioId) {
  const row = stmts.get.get(repositorioId)
  if (!row?.schema_json) return null
  try { return JSON.parse(row.schema_json) } catch { return null }
}

module.exports = { getCursor, saveSchemaHash, saveSchemaJson, getSchemaJson }
