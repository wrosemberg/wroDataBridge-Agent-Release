const { DatabaseSync } = require('node:sqlite')
const path = require('path')
const fs = require('fs')

const DATA_DIR = path.join(__dirname, '../../data')
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true })

const db = new DatabaseSync(path.join(DATA_DIR, 'agent.db'))

db.exec('PRAGMA journal_mode = WAL')
db.exec('PRAGMA foreign_keys = ON')

db.exec(`
  CREATE TABLE IF NOT EXISTS cursors (
    repositorio_id TEXT PRIMARY KEY,
    cursor_valor   TEXT,
    atualizado_em  TEXT,
    schema_hash    TEXT,
    schema_json    TEXT
  );

  CREATE TABLE IF NOT EXISTS fila_envio (
    batch_id       TEXT PRIMARY KEY,
    repositorio_id TEXT NOT NULL,
    payload        BLOB NOT NULL,
    tentativas     INTEGER DEFAULT 0,
    proximo_retry  TEXT,
    criado_em      TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS config_local (
    chave TEXT PRIMARY KEY,
    valor TEXT NOT NULL,
    enc   INTEGER DEFAULT 0
  );
`)

// Migração não destrutiva — ignora se coluna já existir
try { db.exec('ALTER TABLE cursors ADD COLUMN schema_json TEXT') } catch {}

module.exports = db
