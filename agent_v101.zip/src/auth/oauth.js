const axios = require('axios')
const config = require('../config')
const { decrypt } = require('./crypto')
const { debug } = require('../utils/debug')

let cache = null

function tokenEndpoint(logtoUrl) {
  return logtoUrl.replace(/\/(oidc)?\/?$/, '') + '/oidc/token'
}

async function getToken() {
  const devToken = config.get('dev_token')?.valor
  if (devToken) return devToken

  if (cache && cache.expiresAt > Date.now() + 60_000) return cache.token

  const logtoUrl = config.get('logto_url')?.valor
  const clientId = config.get('client_id')?.valor
  const secretRow = config.get('client_secret_enc')
  const resource = config.get('cloud_resource')?.valor

  if (!logtoUrl || !clientId || !secretRow) {
    throw new Error('Credenciais OAuth ausentes — execute: npm run setup')
  }

  const clientSecret = secretRow.enc ? decrypt(secretRow.valor) : secretRow.valor

  const body = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: clientId,
    client_secret: clientSecret,
    resource,
    scope: 'access'
  })

  debug('[oauth] endpoint:', tokenEndpoint(logtoUrl))
  debug('[oauth] client_id:', clientId)
  debug('[oauth] resource:', JSON.stringify(resource))

  let data
  try {
    const res = await axios.post(tokenEndpoint(logtoUrl), body.toString(), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    })
    data = res.data
  } catch (err) {
    const detail = err.response?.data ? JSON.stringify(err.response.data) : err.message
    throw new Error(`Logto token request falhou (${err.response?.status}): ${detail}`)
  }

  cache = { token: data.access_token, expiresAt: Date.now() + data.expires_in * 1000 }
  return cache.token
}

function invalidateToken() {
  cache = null
}

module.exports = { getToken, invalidateToken }
