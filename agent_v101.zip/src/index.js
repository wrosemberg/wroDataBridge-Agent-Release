require('dotenv').config()

const config = require('./config')
const cloudApi = require('./cloud/api')
const scheduler = require('./core/scheduler')
const executor = require('./core/executor')
const { processIntrospectJobs } = require('./core/introspect')
const wsClient = require('./cloud/websocket')
const { applyPendingUpdate } = require('./update/apply')
const { checkForUpdates } = require('./update/checker')
const server = require('./server')
const fb = require('./connectors/firebird')

const VERSAO = config.get('versao_agente')?.valor || 'v1.0.0'
const HEARTBEAT_INTERVAL_MS = 60_000
const CONFIG_REFRESH_MS     = 5 * 60_000
const UPDATE_CHECK_MS       = 6 * 60 * 60_000 // 6 horas

let remoteConfig = null

async function refreshConfig() {
  try {
    remoteConfig = await cloudApi.getConfig()
    scheduler.applyConfig(remoteConfig)
    wsClient.updateConfig(remoteConfig)
    console.log(`[agent] Configuração atualizada: ${remoteConfig.repositorios.length} repositório(s)`)
  } catch (err) {
    console.error(`[agent] Falha ao buscar configuração: ${err.message}`)
  }
}

async function sendHeartbeat() {
  if (!remoteConfig) return
  const gatewayId = remoteConfig.gateway?.id
  if (!gatewayId) return

  try {
    const status = scheduler.getStatus()
    const resp = await cloudApi.heartbeat(gatewayId, VERSAO, status, 0)
    if (resp?.pending_introspect?.length > 0) {
      processIntrospectJobs(resp.pending_introspect, remoteConfig.fontes).catch(err => {
        console.error(`[agent] Erro ao processar introspect jobs: ${err.message}`)
      })
    }
    if (resp?.pending_runs?.length > 0) {
      processRunNow(resp.pending_runs).catch(err => {
        console.error(`[agent] Erro ao processar run-now: ${err.message}`)
      })
    }
    if (resp?.pending_queries?.length > 0) {
      processPendingQueries(resp.pending_queries).catch(err => {
        console.error(`[agent] Erro ao processar queries: ${err.message}`)
      })
    }
  } catch (err) {
    console.error(`[agent] Heartbeat falhou: ${err.message}`)
  }
}

async function processRunNow(repos) {
  for (const repo of repos) {
    const fonte = remoteConfig?.fontes?.find(f => f.id === repo.fonte_id)
    if (!fonte) {
      console.warn(`[run-now] fonte ${repo.fonte_id} não encontrada para ${repo.nome}`)
      continue
    }
    console.log(`[run-now] executando imediatamente: ${repo.nome}`)
    try {
      await executor.run(repo, fonte)
    } catch (err) {
      console.error(`[run-now] ${repo.nome} — erro: ${err.message}`)
    }
  }
}

async function processPendingQueries(queries) {
  const fontes = remoteConfig?.fontes || []

  for (const query of queries) {
    const { id: query_id, fonte_id, sql_query, params } = query

    // Usa a fonte indicada ou a primeira disponível
    const fonte = fontes.find(f => f.id === fonte_id) || fontes[0]

    if (!fonte) {
      await cloudApi.postQueryResult({ query_id, status: 'error', erro: 'Nenhuma fonte configurada no agente' })
      continue
    }

    let db = null
    try {
      const options = fb.buildOptions(fonte)
      db = await fb.connect(options)

      const bindParams = Array.isArray(params) && params.length > 0 ? params : undefined
      const result = bindParams
        ? await db.query(sql_query, bindParams)
        : await db.query(sql_query)

      const rows = Array.from(result).map(row => {
        const out = {}
        for (const [k, v] of Object.entries(row)) {
          out[k.toLowerCase()] = typeof v === 'string' ? v.replace(/\0/g, '').trim() : v
        }
        return out
      })

      console.log(`[query] ${query_id} — ${rows.length} linha(s)`)
      await cloudApi.postQueryResult({ query_id, status: 'done', resultado: rows })
    } catch (err) {
      console.error(`[query] ${query_id} — erro: ${err.message}`)
      await cloudApi.postQueryResult({ query_id, status: 'error', erro: err.message })
    } finally {
      if (db) await fb.detach(db).catch(() => {})
    }
  }
}

async function main() {
  console.log(`[agent] DataBridge Agent ${VERSAO} iniciando...`)

  // Aplica atualização staged (se existir do boot anterior)
  await applyPendingUpdate()

  server.start(8089)

  await refreshConfig()
  await sendHeartbeat()

  wsClient.connect(remoteConfig).catch(err => console.error(`[ws-client] ${err.message}`))

  setInterval(sendHeartbeat, HEARTBEAT_INTERVAL_MS)
  setInterval(refreshConfig, CONFIG_REFRESH_MS)

  checkForUpdates().catch(err => console.error(`[update] ${err.message}`))
  setInterval(() => checkForUpdates().catch(err => console.error(`[update] ${err.message}`)), UPDATE_CHECK_MS)
}

main().catch(err => {
  console.error('[agent] Erro fatal:', err.message)
  process.exit(1)
})
