const odbc = require('odbc')
const { debug } = require('../utils/debug')

// Firebird ODBC devolve datas como strings, não como objetos Date.
// DATE → 'YYYY-MM-DD', TIME → 'HH:MM:SS.mmm', TIMESTAMP → 'YYYY-MM-DD HH:MM:SS.mmm'
const RE_DATE_ONLY = /^\d{4}-\d{2}-\d{2}$/
const RE_DATETIME_TZ = /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}.*[+-]\d{2}:?\d{2}$|^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}.*Z$/
const RE_DATETIME = /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}/
const RE_TIME = /^\d{2}:\d{2}:\d{2}/

// Mapeamento de tipos ODBC SQL para tipos internos do agente.
// Firebird via ODBC reporta o tipo de armazenamento: DECIMAL(10,2) pode chegar como
// SQL_BIGINT (-5) com decimalDigits=2. Por isso verifica-se a escala separadamente.
const ODBC_TYPE_MAP = {
  1:   'text',       // SQL_CHAR
  2:   'numeric',    // SQL_NUMERIC
  3:   'numeric',    // SQL_DECIMAL
  4:   'integer',    // SQL_INTEGER  (verificar decimalDigits)
  5:   'integer',    // SQL_SMALLINT (verificar decimalDigits)
  6:   'numeric',    // SQL_FLOAT
  7:   'numeric',    // SQL_REAL
  8:   'numeric',    // SQL_DOUBLE PRECISION
  9:   'date',       // SQL_DATE
  10:  'time',       // SQL_TIME
  11:  'timestamp',  // SQL_TIMESTAMP
  12:  'text',       // SQL_VARCHAR
  '-1':  'text',     // SQL_LONGVARCHAR
  '-2':  'bytea',    // SQL_BINARY
  '-3':  'bytea',    // SQL_VARBINARY
  '-4':  'bytea',    // SQL_LONGVARBINARY (BLOB)
  '-5':  'integer',  // SQL_BIGINT (verificar decimalDigits — Firebird armazena DECIMAL como BIGINT escalado)
  '-7':  'boolean',  // SQL_BIT
  '-8':  'text',     // SQL_WCHAR
  '-9':  'text',     // SQL_WVARCHAR
  '-10': 'text',     // SQL_WLONGVARCHAR
  91:  'date',       // SQL_TYPE_DATE
  92:  'time',       // SQL_TYPE_TIME
  93:  'timestamp',  // SQL_TYPE_TIMESTAMP
}

// Converte metadados de uma coluna ODBC para o tipo interno do agente.
// A escala (decimalDigits) é o único indicador confiável de que um campo INTEGER/BIGINT
// é na verdade um DECIMAL — Firebird armazena DECIMAL(15,4) como BIGINT*10000 internamente.
function tipoFromOdbc(col) {
  const tipo = ODBC_TYPE_MAP[String(col.dataType)] ?? 'text'
  // O driver ODBC retorna dataType como string — converter para número antes de comparar
  const dt = Number(col.dataType)
  if ((dt === 4 || dt === 5 || dt === -5) && Number(col.decimalDigits) > 0) {
    return 'numeric'
  }
  return tipo
}

// Constrói schemaMeta a partir dos metadados reais das colunas ODBC.
// Mais confiável que inferência por valor — usa o tipo declarado no Firebird.
function schemaFromResultMeta(columns) {
  return columns.map(col => ({
    col:      col.name.toLowerCase(),
    tipo:     tipoFromOdbc(col),
    nullable: col.nullable !== 0
  }))
}

// Retorna o tipo interno inferido a partir do valor JS vindo do ODBC.
// Usado como fallback quando o driver não expõe metadados de coluna.
function inferTipo(v) {
  if (v === null || v === undefined) return null
  if (typeof v === 'boolean') return 'boolean'
  if (typeof v === 'number') return Number.isInteger(v) ? 'integer' : 'numeric'
  if (v instanceof Date) return 'timestamp'
  if (Buffer.isBuffer(v)) return 'bytea'
  if (typeof v === 'string') {
    const s = v.trim()
    if (RE_DATETIME_TZ.test(s)) return 'timestamptz'
    if (RE_DATETIME.test(s))    return 'timestamp'
    if (RE_DATE_ONLY.test(s))   return 'date'
    if (RE_TIME.test(s))        return 'time'
  }
  return 'text'
}

function buildConnectionString(fonte) {
  const host = (fonte.host || 'localhost').trim()
  const port = fonte.porta || 3050
  const driver = fonte.opcoes_extra?.odbc_driver || 'Firebird ODBC Driver'
  const dbname = `${host}/${port}:${fonte.banco}`
  return `DRIVER={${driver}};DBNAME=${dbname};UID=${fonte.usuario};PWD=${fonte.senha_plain};CHARSET=UTF8;`
}

function buildOptions(fonte) {
  return { connectionString: buildConnectionString(fonte) }
}

async function connect(options) {
  const safeStr = options.connectionString.replace(/PWD=[^;]*/i, 'PWD=***')
  debug('[firebird] ODBC connection string:', safeStr)
  try {
    return await odbc.connect(options.connectionString)
  } catch (err) {
    const detail = err.odbcErrors?.map(e => `[${e.state}] ${e.message}`).join(' | ') || err.message
    throw new Error(detail)
  }
}

async function detach(db) {
  try { await db.close() } catch {}
}

async function queryMeta(db, sql) {
  const metaSql = sql.trim().replace(/^SELECT\s+/i, 'SELECT FIRST 10 ')
  const result = await db.query(metaSql)
  return normalizeRows(Array.from(result))
}

function normalizeRows(rows) {
  return rows.map(row => {
    const out = {}
    for (const [k, v] of Object.entries(row)) {
      out[k.toLowerCase()] = typeof v === 'string' ? v.replace(/\0/g, '').trim() : v
    }
    return out
  })
}

async function streamChunks(db, sql, params, chunkSize, onChunk) {
  const odbcSql = sql.replace(/:cursor/g, '?')
  const bindParams = params.length > 0 ? params : null
  let offset = 0
  let columnsMeta = null

  while (true) {
    // Injeta FIRST/SKIP após SELECT — compatível com todas as versões do Firebird via ODBC
    const skipPart = offset > 0 ? `SKIP ${offset} ` : ''
    const pagedSql = odbcSql.replace(/^\s*SELECT\b/i, `SELECT FIRST ${chunkSize} ${skipPart}`)
    const result = bindParams
      ? await db.query(pagedSql, bindParams)
      : await db.query(pagedSql)

    // Captura metadados de coluna na primeira execução (tipo declarado no Firebird, não inferido)
    if (!columnsMeta && result.columns && result.columns.length > 0) {
      columnsMeta = result.columns
    }

    debug(`[firebird] FIRST ${chunkSize} ${skipPart}→ ${result.length} linha(s)`)
    const batch = normalizeRows(result)
    if (batch.length === 0) break

    await onChunk(batch, columnsMeta)
    offset += batch.length
    if (batch.length < chunkSize) break
  }
}

function extractSchema(rows) {
  if (!rows || rows.length === 0) return []
  return Object.keys(rows[0]).map(col => {
    let tipo = 'text'
    for (const row of rows) {
      const t = inferTipo(row[col])
      if (t !== null) { tipo = t; break }
    }
    return { col: col.toLowerCase(), tipo, nullable: true }
  })
}

async function listTables(db) {
  const sql = `SELECT TRIM(RDB$RELATION_NAME) AS TABLE_NAME
               FROM RDB$RELATIONS
               WHERE RDB$SYSTEM_FLAG = 0 AND RDB$VIEW_BLR IS NULL
               ORDER BY RDB$RELATION_NAME`
  const rows = await db.query(sql)
  return Array.from(rows).map(r => (r.TABLE_NAME || r.table_name || '').trim()).filter(Boolean)
}

async function getPrimaryKeys(db, tableName) {
  const upper = tableName.toUpperCase()
  const sql = `SELECT TRIM(s.RDB$FIELD_NAME) AS COL
               FROM RDB$RELATION_CONSTRAINTS rc
               JOIN RDB$INDEX_SEGMENTS s ON s.RDB$INDEX_NAME = rc.RDB$INDEX_NAME
               WHERE rc.RDB$CONSTRAINT_TYPE = 'PRIMARY KEY'
                 AND TRIM(rc.RDB$RELATION_NAME) = '${upper}'
               ORDER BY s.RDB$FIELD_POSITION`
  const rows = await db.query(sql)
  return Array.from(rows).map(r => (r.COL || r.col || '').trim().toLowerCase()).filter(Boolean)
}

module.exports = { buildOptions, connect, detach, queryMeta, streamChunks, extractSchema, schemaFromResultMeta, listTables, getPrimaryKeys }
