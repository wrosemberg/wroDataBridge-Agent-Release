// Delays em segundos: 5, 25, 125 (base 5, expoente)
const BASE = 5
const MAX_RETRIES = 3

function delayFor(tentativa) {
  return BASE ** tentativa
}

async function withRetry(fn, label = 'operação') {
  let lastErr
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err
      if (attempt < MAX_RETRIES) {
        const wait = delayFor(attempt)
        console.warn(`[retry] ${label} — tentativa ${attempt}/${MAX_RETRIES}, aguardando ${wait}s: ${err.message}`)
        await new Promise(r => setTimeout(r, wait * 1000))
      }
    }
  }
  throw lastErr
}

module.exports = { withRetry, delayFor, MAX_RETRIES }
