const crypto = require('crypto')

const RE_DATE_ONLY   = /^\d{4}-\d{2}-\d{2}$/
const RE_DATETIME_TZ = /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}.*[+-]\d{2}:?\d{2}$|^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}.*Z$/
const RE_DATETIME    = /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}/
const RE_TIME        = /^\d{2}:\d{2}:\d{2}/

function inferTipo(v) {
  if (v === null || v === undefined) return null
  if (typeof v === 'boolean') return 'boolean'
  if (typeof v === 'number') return Number.isInteger(v) ? 'integer' : 'numeric'
  if (v instanceof Date) return 'timestamp'
  if (Buffer.isBuffer(v)) return 'bytea'
  if (typeof v === 'string') {
    const s = v.trim()
    if (RE_DATETIME_TZ.test(s)) return 'timestamptz'
    if (RE_DATETIME.test(s))    return 'timestamp'
    if (RE_DATE_ONLY.test(s))   return 'date'
    if (RE_TIME.test(s))        return 'time'
  }
  return 'text'
}

function captureSchema(rows) {
  if (!rows || rows.length === 0) return []
  return Object.keys(rows[0]).map(col => {
    let tipo = 'text'
    for (const row of rows) {
      const t = inferTipo(row[col])
      if (t !== null) { tipo = t; break }
    }
    return { col: col.toLowerCase(), tipo, nullable: true }
  })
}

function hashSchema(schema) {
  // Apenas col+tipo, ordenado por nome — exclui nullable (oscila entre inferência e metadados ODBC)
  const normalized = schema
    .map(c => ({ col: c.col, tipo: c.tipo }))
    .sort((a, b) => a.col.localeCompare(b.col))
  return crypto.createHash('sha256').update(JSON.stringify(normalized)).digest('hex')
}

function diffSchema(oldSchema, newSchema) {
  const oldMap = Object.fromEntries(oldSchema.map(c => [c.col, c]))
  const newMap = Object.fromEntries(newSchema.map(c => [c.col, c]))

  const adicionadas = newSchema.filter(c => !oldMap[c.col])
  const removidas   = oldSchema.filter(c => !newMap[c.col])
  const alteradas   = newSchema.filter(c => oldMap[c.col] && oldMap[c.col].tipo !== c.tipo)

  return { adicionadas, removidas, alteradas }
}

module.exports = { captureSchema, hashSchema, diffSchema }
