// WebSocket cliente desabilitado — o cloud não expõe mais endpoint WS.
// Toda comunicação agente→cloud ocorre via heartbeat HTTP (polling).
// Mantido como no-op para compatibilidade com as chamadas em index.js.

function connect(remoteConfig) {
  console.log('[ws-client] Modo heartbeat-only — WebSocket não utilizado')
  return Promise.resolve()
}

function updateConfig(remoteConfig) {
  // no-op
}

module.exports = { connect, updateConfig }
