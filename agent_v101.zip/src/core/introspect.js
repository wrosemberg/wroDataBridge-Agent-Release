const { decrypt } = require('../auth/crypto')
const fb = require('../connectors/firebird')
const cloudApi = require('../cloud/api')

// Executa um job de introspecção e retorna o resultado (lança erro em falha)
async function runIntrospectJob(job, fontes) {
  const fonte = fontes.find(f => f.id === job.fonte_id)
  if (!fonte) throw new Error('Fonte não encontrada neste gateway')

  let senha
  try {
    senha = fonte.senha_enc ? decrypt(fonte.senha_enc) : ''
  } catch {
    senha = fonte.senha_enc
  }
  const fonteConf = { ...fonte, senha_plain: senha }
  const opts = fb.buildOptions(fonteConf)

  let db
  try {
    db = await fb.connect(opts)

    if (job.tipo === 'connection_test') {
      return { ok: true }
    } else if (job.tipo === 'list_tables') {
      return { tables: await fb.listTables(db) }
    } else if (job.tipo === 'get_pks') {
      const tableName = job.params?.table_name
      if (!tableName) throw new Error('table_name não informado no job')
      return { pks: await fb.getPrimaryKeys(db, tableName) }
    }
    throw new Error(`Tipo de introspect desconhecido: ${job.tipo}`)
  } finally {
    if (db) await fb.detach(db)
  }
}

async function processIntrospectJobs(jobs, fontes) {
  if (!jobs || jobs.length === 0) return

  for (const job of jobs) {
    try {
      const resultado = await runIntrospectJob(job, fontes)
      await cloudApi.postIntrospectResult({ job_id: job.id, status: 'done', resultado })
      console.log(`[introspect] job ${job.id} (${job.tipo}) — concluído`)
    } catch (err) {
      console.error(`[introspect] job ${job.id} (${job.tipo}) — erro: ${err.message}`)
      try {
        await cloudApi.postIntrospectResult({ job_id: job.id, status: 'error', erro: err.message })
      } catch {}
    }
  }
}

module.exports = { processIntrospectJobs, runIntrospectJob }
