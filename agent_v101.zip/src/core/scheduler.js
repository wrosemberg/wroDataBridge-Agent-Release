const cron = require('node-cron')
const { debug } = require('../utils/debug')
const executor = require('./executor')
const cursorMod = require('./cursor')

let _config = { fontes: [], repositorios: [] }
const _jobs = new Map() // id → { type: 'cron'|'interval', job?, timerId? }

function fonteById(id) {
  return _config.fontes.find(f => f.id === id)
}

function stopJob(entry) {
  if (!entry) return
  if (entry.type === 'cron') entry.job.stop()
  else clearInterval(entry.timerId)
}

function scheduleRepo(repo) {
  const fonte = fonteById(repo.fonte_id)
  if (!fonte) {
    console.warn(`[scheduler] ${repo.nome} — fonte ${repo.fonte_id} não encontrada`)
    return
  }

  if (_jobs.has(repo.id)) {
    stopJob(_jobs.get(repo.id))
    _jobs.delete(repo.id)
  }

  const run = async () => {
    try {
      await executor.run(repo, fonte)
    } catch (err) {
      console.error(`[scheduler] ${repo.nome} — erro: ${err.message}`)
    }
  }

  if (repo.modo === 'batch') {
    if (!repo.schedule_cron) {
      debug(`[scheduler] ${repo.nome} — batch sem cron, ignorando`)
      return
    }
    if (!cron.validate(repo.schedule_cron)) {
      console.warn(`[scheduler] ${repo.nome} — cron inválido: ${repo.schedule_cron}`)
      return
    }
    const job = cron.schedule(repo.schedule_cron, run, { timezone: 'America/Sao_Paulo' })
    _jobs.set(repo.id, { type: 'cron', job })
    console.log(`[scheduler] ${repo.nome} — batch agendado: ${repo.schedule_cron}`)
  } else if (repo.modo === 'realtime') {
    const intervalo = repo.intervalo_segundos
    if (!intervalo || intervalo < 10) {
      console.warn(`[scheduler] ${repo.nome} — realtime requer intervalo_segundos >= 10`)
      return
    }
    const timerId = setInterval(run, intervalo * 1000)
    _jobs.set(repo.id, { type: 'interval', timerId })
    console.log(`[scheduler] ${repo.nome} — realtime agendado: a cada ${intervalo}s`)
  } else {
    debug(`[scheduler] ${repo.nome} — modo ${repo.modo} não requer agendamento automático`)
  }
}

function applyConfig(newConfig) {
  _config = newConfig

  for (const entry of _jobs.values()) stopJob(entry)
  _jobs.clear()
  for (const repo of _config.repositorios) {
    debug(`[scheduler] repo: ${repo.nome} | status: ${repo.status} | modo: ${repo.modo}`)
    if (repo.status === 'ativo') scheduleRepo(repo)
  }
}

function getStatus() {
  return _config.repositorios.map(r => ({
    id: r.id,
    nome: r.nome,
    status: _jobs.has(r.id) ? 'agendado' : (r.status === 'ativo' ? 'sem_agenda' : r.status)
  }))
}

module.exports = { applyConfig, getStatus }
