const db = require('../db/sqlite')
const zlib = require('zlib')

const stmts = {
  insert: db.prepare(`
    INSERT OR IGNORE INTO fila_envio (batch_id, repositorio_id, payload, tentativas)
    VALUES (?, ?, ?, 0)
  `),
  delete: db.prepare('DELETE FROM fila_envio WHERE batch_id = ?'),
  incrementRetry: db.prepare(`
    UPDATE fila_envio SET tentativas = tentativas + 1, proximo_retry = ?
    WHERE batch_id = ?
  `),
  getPending: db.prepare(`
    SELECT batch_id, repositorio_id, payload, tentativas
    FROM fila_envio
    WHERE proximo_retry IS NULL OR proximo_retry <= datetime('now')
    ORDER BY criado_em
    LIMIT 50
  `)
}

function enqueue(batchId, repositorioId, dados) {
  const compressed = zlib.gzipSync(JSON.stringify(dados))
  stmts.insert.run(batchId, repositorioId, compressed)
}

function dequeue(batchId) {
  stmts.delete.run(batchId)
}

function markRetry(batchId, delaySecs) {
  const next = new Date(Date.now() + delaySecs * 1000).toISOString()
  stmts.incrementRetry.run(next, batchId)
}

function getPending() {
  return stmts.getPending.all().map(row => ({
    ...row,
    payload: JSON.parse(zlib.gunzipSync(row.payload).toString())
  }))
}

module.exports = { enqueue, dequeue, markRetry, getPending }
