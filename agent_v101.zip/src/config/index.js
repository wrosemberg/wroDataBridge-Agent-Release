const db = require('../db/sqlite')

const stmt = {
  get: db.prepare('SELECT valor, enc FROM config_local WHERE chave = ?'),
  set: db.prepare(`
    INSERT INTO config_local (chave, valor, enc) VALUES (?, ?, ?)
    ON CONFLICT(chave) DO UPDATE SET valor = excluded.valor, enc = excluded.enc
  `),
  all: db.prepare('SELECT chave, valor, enc FROM config_local')
}

function get(chave) {
  return stmt.get.get(chave) || null
}

function set(chave, valor, enc = 0) {
  stmt.set.run(chave, String(valor), enc)
}

function getAll() {
  return stmt.all.all()
}

module.exports = { get, set, getAll }
