const enabled = process.env.DEBUG === 'true' || process.env.DEBUG === '1'

function debug(...args) {
  if (enabled) console.log(...args)
}

module.exports = { debug }
