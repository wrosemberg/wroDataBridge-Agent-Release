const axios = require('axios')
const config = require('../config')
const { getToken, invalidateToken } = require('../auth/oauth')

function cloudUrl() {
  const url = config.get('cloud_url')?.valor
  if (!url) throw new Error('cloud_url não configurado — execute: npm run setup')
  return url.replace(/\/$/, '')
}

async function request(method, path, data) {
  const token = await getToken()
  try {
    const res = await axios({ method, url: cloudUrl() + path, data, headers: { Authorization: `Bearer ${token}` } })
    return res.data
  } catch (err) {
    if (err.response?.status === 401) {
      const detalhe = err.response?.data?.detalhe || err.response?.data?.error || 'sem detalhe'
      console.error('[api] 401 detalhe:', detalhe)
      invalidateToken()
      throw new Error('Token rejeitado — renovando na próxima tentativa')
    }
    const body = err.response?.data
    const msg = body?.detalhe || body?.error || err.message
    throw new Error(msg)
  }
}

async function heartbeat(gatewayId, versao, statusRepositorios, filaPendente) {
  return request('POST', '/api/v1/heartbeat', {
    gateway_id: gatewayId,
    versao,
    status_repositorios: statusRepositorios,
    fila_pendente: filaPendente
  })
}

async function postIntrospectResult(payload) {
  return request('POST', '/api/v1/agent/introspect-result', payload)
}

async function getConfig() {
  return request('GET', '/api/v1/agent/config')
}

async function ingest(batchId, repositorioId, dados, schemaMeta = null) {
  return request('POST', '/api/v1/sync/ingest', {
    batch_id: batchId,
    repositorio_id: repositorioId,
    dados,
    ...(schemaMeta ? { schema_meta: schemaMeta } : {})
  })
}

async function reportExecution(payload) {
  return request('POST', '/api/v1/sync/execution', payload)
}

async function reportSchemaDrift(payload) {
  return request('POST', '/api/v1/sync/schema-drift', payload)
}

async function getLatestVersion() {
  return request('GET', '/api/v1/agent/latest-version')
}

async function reportRetryFailure(repositorioId, batchId, erro) {
  return request('POST', '/api/v1/sync/retry-failure', { repositorio_id: repositorioId, batch_id: batchId, erro })
}

async function completarSync(repositorioId) {
  return request('POST', '/api/v1/sync/complete', { repositorio_id: repositorioId })
}

async function postQueryResult(payload) {
  return request('POST', '/api/v1/agent/query-result', payload)
}

module.exports = { heartbeat, getConfig, ingest, reportExecution, postIntrospectResult, reportSchemaDrift, getLatestVersion, reportRetryFailure, completarSync, postQueryResult }
