const { v4: uuidv4 } = require('uuid')
const { decrypt } = require('../auth/crypto')
const { debug } = require('../utils/debug')
const fb = require('../connectors/firebird')
const cursorMod = require('./cursor')
const queue = require('./queue')
const { withRetry } = require('./retry')
const { captureSchema, hashSchema, diffSchema } = require('./fingerprint')
const cloudApi = require('../cloud/api')

// Substitui :cursor pelo valor salvo e retorna [sql, params]
function buildSql(sqlExtracao, cursorValor, syncTipo, cursorTipo) {
  const hasCursorPlaceholder = /:cursor/i.test(sqlExtracao)
  if (syncTipo === 'full_refresh' || !cursorValor || !hasCursorPlaceholder) {
    const defaultCursor = cursorTipo === 'integer' ? '0' : "'1900-01-01'"
    return [sqlExtracao.replace(/:cursor/gi, defaultCursor), []]
  }
  const sql = sqlExtracao.replace(/:cursor/gi, '?')
  return [sql, [cursorValor]]
}

async function run(repositorio, fonte) {
  const repoId = repositorio.id
  const label = `[executor] ${repositorio.nome}`

  console.log(`${label} — iniciando`)

  // Decripta senha da fonte (fallback p/ texto simples em dev)
  let senha
  try {
    senha = fonte.senha_enc ? decrypt(fonte.senha_enc) : ''
  } catch {
    senha = fonte.senha_enc
  }
  const fonteConf = { ...fonte, senha_plain: senha }

  const { schema_hash: hashSalvo } = cursorMod.getCursor(repoId)
  const [sql, params] = buildSql(repositorio.sql_extracao, repositorio.cursor_valor, repositorio.sync_tipo, repositorio.cursor_tipo)
  debug(`${label} — SQL: ${sql} | params: ${JSON.stringify(params)}`)

  const fbOptions = fb.buildOptions(fonteConf)
  let db
  try {
    db = await fb.connect(fbOptions)
  } catch (err) {
    console.error(`${label} — falha ao conectar no Firebird: ${err.message}`)
    throw err
  }

  let primeiroChunk = true
  let totalExtraido = 0
  const chunkSize = repositorio.chunk_size || 1000

  try {
    await fb.streamChunks(db, sql, params, chunkSize, async (chunk, columnsMeta) => {
      totalExtraido += chunk.length

      // Captura schema e envia junto ao primeiro chunk para auto-criar tabela no cloud
      let schemaMeta = null
      if (primeiroChunk) {
        primeiroChunk = false
        // Prefere metadados ODBC reais (tipo declarado no Firebird) sobre inferência por valor.
        // Metadados ODBC identificam corretamente DECIMAL(10,2) mesmo quando o valor é 6.00.
        schemaMeta = (columnsMeta && columnsMeta.length > 0)
          ? fb.schemaFromResultMeta(columnsMeta)
          : captureSchema(chunk)
        const hash = hashSchema(schemaMeta)

        if (hashSalvo && hash !== hashSalvo) {
          const oldFp = cursorMod.getSchemaJson(repoId)

          if (oldFp) {
            // Compara apenas nomes de coluna (ordenados) — mudança de tipo não pausa o repositório
            const colsAntes = oldFp.map(c => c.col).sort().join(',')
            const colsAgora = schemaMeta.map(c => c.col).sort().join(',')

            if (colsAntes !== colsAgora) {
              // Mudança estrutural real (colunas adicionadas ou removidas)
              console.warn(`${label} — SCHEMA DRIFT detectado — pausando repositório`)
              const diff = diffSchema(oldFp, schemaMeta)

              cursorMod.saveSchemaHash(repoId, hash)
              cursorMod.saveSchemaJson(repoId, schemaMeta)

              await cloudApi.reportSchemaDrift({
                repositorio_id: repoId,
                hash_anterior: hashSalvo,
                hash_novo: hash,
                schema_json: schemaMeta,
                diff_json: diff
              }).catch(e => console.error(`${label} — falha ao reportar drift: ${e.message}`))

              throw new Error('Schema drift detectado — sync pausada até resolução no Admin Panel')
            }
          }

          // Sem fingerprint anterior (agente atualizado) ou mesmas colunas: atualiza silenciosamente
          debug(`${label} — hash de schema atualizado (${oldFp ? 'mesmas colunas' : 'fingerprint inicial'})`)
        }

        cursorMod.saveSchemaHash(repoId, hash)
        cursorMod.saveSchemaJson(repoId, schemaMeta)
      }

      const batchId = uuidv4()
      queue.enqueue(batchId, repoId, chunk)

      try {
        await withRetry(async () => {
          await cloudApi.ingest(batchId, repoId, chunk, schemaMeta)
          queue.dequeue(batchId)
        }, `ingest ${batchId.slice(0, 8)}`)
      } catch (err) {
        // Todas as tentativas esgotadas — notifica o cloud para disparar alerta
        cloudApi.reportRetryFailure(repoId, batchId, err.message).catch(() => {})
        throw err
      }

      console.log(`${label} — chunk enviado: ${chunk.length} registros`)
    })
  } finally {
    await fb.detach(db)
  }

  if (repositorio.sync_tipo === 'incremental' && repositorio.cursor_coluna) {
    try {
      await cloudApi.completarSync(repoId)
    } catch (err) {
      console.warn(`${label} — falha ao atualizar cursor no servidor: ${err.message}`)
    }
  }

  console.log(`${label} — concluído: ${totalExtraido} registros`)
  return { totalExtraido }
}

module.exports = { run }
