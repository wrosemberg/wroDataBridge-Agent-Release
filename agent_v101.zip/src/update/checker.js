const https = require('https')
const http = require('http')
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')
const { exec } = require('child_process')
const util = require('util')
const cloudApi = require('../cloud/api')
const config = require('../config')

const execAsync = util.promisify(exec)

const STAGING_DIR = path.join(process.cwd(), 'update-staging')
const STAGING_ZIP = path.join(process.cwd(), 'update-download.zip')
const UPDATE_WINDOW_START = 0  // 00:00
const UPDATE_WINDOW_END   = 5  // 05:00

async function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const proto = url.startsWith('https') ? https : http
    const file = fs.createWriteStream(destPath)
    proto.get(url, res => {
      if (res.statusCode !== 200) {
        file.destroy()
        fs.unlink(destPath, () => {})
        return reject(new Error(`HTTP ${res.statusCode} ao baixar atualização`))
      }
      res.pipe(file)
      file.on('finish', () => { file.close(); resolve() })
    }).on('error', err => { file.destroy(); fs.unlink(destPath, () => {}); reject(err) })
  })
}

async function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256')
    const stream = fs.createReadStream(filePath)
    stream.on('data', d => hash.update(d))
    stream.on('end', () => resolve(hash.digest('hex')))
    stream.on('error', reject)
  })
}

async function extractZip(zipPath, destPath) {
  fs.mkdirSync(destPath, { recursive: true })
  if (process.platform === 'win32') {
    await execAsync(`powershell -Command "Expand-Archive -Path '${zipPath}' -DestinationPath '${destPath}' -Force"`)
  } else {
    await execAsync(`unzip -o '${zipPath}' -d '${destPath}'`)
  }
}

async function checkForUpdates() {
  const versaoAtual = config.get('versao_agente')?.valor || 'v0.0.0'
  let latest
  try {
    latest = await cloudApi.getLatestVersion()
  } catch {
    return // sem versão publicada — situação normal
  }

  if (!latest?.versao || latest.versao === versaoAtual) return
  console.log(`[update] Nova versão disponível: ${latest.versao} (atual: ${versaoAtual})`)

  const hora = new Date().getHours()
  const emJanela = hora >= UPDATE_WINDOW_START && hora < UPDATE_WINDOW_END

  if (!latest.critico && !emJanela) {
    console.log(`[update] Aguardando janela de manutenção (00h–05h) para atualização não-crítica`)
    return
  }

  const motivo = latest.critico ? 'crítica' : 'janela de manutenção'
  console.log(`[update] Iniciando download (${motivo}): ${latest.url_download}`)

  try {
    await downloadFile(latest.url_download, STAGING_ZIP)
    const checksum = await sha256File(STAGING_ZIP)
    if (checksum !== latest.checksum_sha256) {
      console.error(`[update] Checksum inválido. Esperado: ${latest.checksum_sha256} | Obtido: ${checksum}`)
      fs.unlink(STAGING_ZIP, () => {})
      return
    }
    console.log(`[update] Checksum OK. Extraindo para staging...`)
    await extractZip(STAGING_ZIP, STAGING_DIR)
    fs.unlink(STAGING_ZIP, () => {})
    fs.writeFileSync(path.join(STAGING_DIR, 'VERSION'), latest.versao)
    console.log(`[update] Atualização pronta. Reiniciando serviço...`)
    process.exit(0) // serviço Windows/systemd reinicia automaticamente e aplica o update
  } catch (err) {
    console.error(`[update] Falha: ${err.message}`)
    fs.unlink(STAGING_ZIP, () => {})
  }
}

module.exports = { checkForUpdates }
